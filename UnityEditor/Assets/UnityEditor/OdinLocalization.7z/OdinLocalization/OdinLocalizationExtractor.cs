using System.Xml;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.Text.RegularExpressions;

/// <summary>
/// Odin本地化工具，用于提取Odin Inspector的XML文档中的文本，并生成本地化文件
/// </summary>
public class OdinLocalizationExtractor : EditorWindow
{
    private string xmlSourcePath = "";
    private string outputJsonPath = "";
    private string outputXmlPath = "";
    private string language = "zh-CN";
    private Vector2 scrollPosition;
    private bool showExtractedTexts = false;
    private Dictionary<string, string> extractedTexts = new Dictionary<string, string>();
    private bool extractionComplete = false;
    
    // 源代码提取相关
    private string codeSourcePath = "";
    private string codeOutputJsonPath = "";
    private bool includeSubfolders = true;
    private string[] attributesToExtract = new string[] {
        "InfoBox", "Title", "LabelText", "SuffixLabel", "GUIColor", "TabGroup", "BoxGroup", "FoldoutGroup",
        "ToggleGroup", "ButtonGroup", "HorizontalGroup", "VerticalGroup", "TitleGroup", "PropertyTooltip"
    };
    private bool[] attributeSelections;
    private string fileFilter = "*.cs";
    private int selectedTab = 0;
    private string[] tabs = new string[] { "XML文档提取", "代码属性提取" };
    
    [MenuItem("Tools/Odin Inspector/本地化提取工具")]
    public static void ShowWindow()
    {
        OdinLocalizationExtractor window = GetWindow<OdinLocalizationExtractor>("Odin本地化工具");
        window.minSize = new Vector2(450, 550);
    }
    
    private void OnEnable()
    {
        // 初始化属性选择数组
        attributeSelections = new bool[attributesToExtract.Length];
        for (int i = 0; i < attributeSelections.Length; i++)
        {
            attributeSelections[i] = true;
        }
    }
    
    private void OnGUI()
    {
        selectedTab = GUILayout.Toolbar(selectedTab, tabs);
        
        scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
        
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Odin Inspector 本地化提取工具", EditorStyles.boldLabel);
        GUILayout.Space(10);
        
        switch (selectedTab)
        {
            case 0: // XML文档提取
                DrawXmlExtractionUI();
                break;
            case 1: // 代码属性提取
                DrawCodeExtractionUI();
                break;
        }
        
        EditorGUILayout.EndScrollView();
    }
    
    private void DrawXmlExtractionUI()
    {
        EditorGUILayout.HelpBox("此功能从Odin Inspector的XML文档中提取文本并生成本地化文件。\n请确保您有访问这些XML文件的权限。", MessageType.Info);
        
        GUILayout.Space(10);
        EditorGUILayout.LabelField("源文件设置", EditorStyles.boldLabel);
        
        EditorGUILayout.BeginHorizontal();
        xmlSourcePath = EditorGUILayout.TextField("XML源文件路径:", xmlSourcePath);
        if (GUILayout.Button("浏览", GUILayout.Width(60)))
        {
            string path = EditorUtility.OpenFilePanel("选择Odin XML文件", Application.dataPath, "xml");
            if (!string.IsNullOrEmpty(path))
            {
                xmlSourcePath = path;
                // 自动设置输出路径
                string directory = Path.GetDirectoryName(path);
                string fileName = Path.GetFileNameWithoutExtension(path);
                outputXmlPath = Path.Combine(directory, fileName + "_localized.xml");
                outputJsonPath = Path.Combine(directory, fileName + "_" + language + ".json");
            }
        }
        EditorGUILayout.EndHorizontal();
        
        GUILayout.Space(5);
        EditorGUILayout.BeginHorizontal();
        outputXmlPath = EditorGUILayout.TextField("输出XML路径:", outputXmlPath);
        if (GUILayout.Button("浏览", GUILayout.Width(60)))
        {
            string path = EditorUtility.SaveFilePanel("保存本地化XML文件", Path.GetDirectoryName(xmlSourcePath), Path.GetFileNameWithoutExtension(xmlSourcePath) + "_localized", "xml");
            if (!string.IsNullOrEmpty(path))
            {
                outputXmlPath = path;
            }
        }
        EditorGUILayout.EndHorizontal();
        
        GUILayout.Space(5);
        EditorGUILayout.BeginHorizontal();
        language = EditorGUILayout.TextField("语言代码:", language);
        EditorGUILayout.EndHorizontal();
        
        GUILayout.Space(5);
        EditorGUILayout.BeginHorizontal();
        outputJsonPath = EditorGUILayout.TextField("输出JSON路径:", outputJsonPath);
        if (GUILayout.Button("浏览", GUILayout.Width(60)))
        {
            string path = EditorUtility.SaveFilePanel("保存JSON文件", Path.GetDirectoryName(xmlSourcePath), Path.GetFileNameWithoutExtension(xmlSourcePath) + "_" + language, "json");
            if (!string.IsNullOrEmpty(path))
            {
                outputJsonPath = path;
            }
        }
        EditorGUILayout.EndHorizontal();
        
        GUILayout.Space(15);
        
        EditorGUI.BeginDisabledGroup(string.IsNullOrEmpty(xmlSourcePath));
        if (GUILayout.Button("提取XML文档本地化文本", GUILayout.Height(30)))
        {
            extractedTexts = ExtractTexts(xmlSourcePath, outputJsonPath, outputXmlPath);
            extractionComplete = true;
            showExtractedTexts = true;
            EditorUtility.DisplayDialog("提取完成", "本地化文本提取完成！\n\n已生成XML文件: " + outputXmlPath + "\n\n已生成JSON文件: " + outputJsonPath, "确定");
        }
        EditorGUI.EndDisabledGroup();
        
        if (extractionComplete && selectedTab == 0)
        {
            GUILayout.Space(10);
            EditorGUILayout.HelpBox("提取完成！生成了" + extractedTexts.Count + "个本地化条目。", MessageType.Info);
            
            showExtractedTexts = EditorGUILayout.Foldout(showExtractedTexts, "显示提取的文本 (" + extractedTexts.Count + " 项)");
            
            if (showExtractedTexts)
            {
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                foreach (var kvp in extractedTexts)
                {
                    EditorGUILayout.LabelField(kvp.Key, EditorStyles.boldLabel);
                    EditorGUILayout.LabelField(kvp.Value, EditorStyles.wordWrappedLabel);
                    EditorGUILayout.Space();
                }
                EditorGUILayout.EndVertical();
            }
        }
    }
    
    private void DrawCodeExtractionUI()
    {
        EditorGUILayout.HelpBox("此功能从C#源代码中提取Odin特性的文本内容并生成本地化文件。\n例如InfoBox(\"This is a message\")中的文本。", MessageType.Info);
        
        GUILayout.Space(10);
        EditorGUILayout.LabelField("源代码设置", EditorStyles.boldLabel);
        
        EditorGUILayout.BeginHorizontal();
        codeSourcePath = EditorGUILayout.TextField("源代码路径:", codeSourcePath);
        if (GUILayout.Button("浏览", GUILayout.Width(60)))
        {
            string path = EditorUtility.OpenFolderPanel("选择源代码文件夹", Application.dataPath, "");
            if (!string.IsNullOrEmpty(path))
            {
                codeSourcePath = path;
                // 自动设置输出路径
                string directory = Path.GetDirectoryName(path);
                string folderName = Path.GetFileName(path);
                codeOutputJsonPath = Path.Combine(directory, "OdinAttributes_" + language + ".json");
            }
        }
        EditorGUILayout.EndHorizontal();
        
        GUILayout.Space(5);
        includeSubfolders = EditorGUILayout.Toggle("包括子文件夹", includeSubfolders);
        
        GUILayout.Space(5);
        fileFilter = EditorGUILayout.TextField("文件过滤器:", fileFilter);
        
        GUILayout.Space(5);
        EditorGUILayout.BeginHorizontal();
        codeOutputJsonPath = EditorGUILayout.TextField("输出JSON路径:", codeOutputJsonPath);
        if (GUILayout.Button("浏览", GUILayout.Width(60)))
        {
            string path = EditorUtility.SaveFilePanel("保存JSON文件", Path.GetDirectoryName(codeSourcePath), "OdinAttributes_" + language, "json");
            if (!string.IsNullOrEmpty(path))
            {
                codeOutputJsonPath = path;
            }
        }
        EditorGUILayout.EndHorizontal();
        
        GUILayout.Space(10);
        EditorGUILayout.LabelField("选择要提取的Odin特性:", EditorStyles.boldLabel);
        
        EditorGUILayout.BeginVertical(EditorStyles.helpBox);
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("全选", GUILayout.Width(60)))
        {
            for (int i = 0; i < attributeSelections.Length; i++)
                attributeSelections[i] = true;
        }
        if (GUILayout.Button("全不选", GUILayout.Width(60)))
        {
            for (int i = 0; i < attributeSelections.Length; i++)
                attributeSelections[i] = false;
        }
        EditorGUILayout.EndHorizontal();
        
        EditorGUILayout.BeginVertical();
        for (int i = 0; i < attributesToExtract.Length; i++)
        {
            attributeSelections[i] = EditorGUILayout.ToggleLeft(attributesToExtract[i], attributeSelections[i]);
        }
        EditorGUILayout.EndVertical();
        EditorGUILayout.EndVertical();
        
        GUILayout.Space(15);
        
        EditorGUI.BeginDisabledGroup(string.IsNullOrEmpty(codeSourcePath));
        if (GUILayout.Button("提取代码属性本地化文本", GUILayout.Height(30)))
        {
            List<string> selectedAttributes = new List<string>();
            for (int i = 0; i < attributesToExtract.Length; i++)
            {
                if (attributeSelections[i])
                    selectedAttributes.Add(attributesToExtract[i]);
            }
            
            extractedTexts = ExtractAttributeTexts(codeSourcePath, codeOutputJsonPath, includeSubfolders, fileFilter, selectedAttributes.ToArray());
            extractionComplete = true;
            showExtractedTexts = true;
            EditorUtility.DisplayDialog("提取完成", "代码属性本地化文本提取完成！\n\n已生成JSON文件: " + codeOutputJsonPath + "\n\n共提取 " + extractedTexts.Count + " 个文本条目", "确定");
        }
        EditorGUI.EndDisabledGroup();
        
        if (extractionComplete && selectedTab == 1)
        {
            GUILayout.Space(10);
            EditorGUILayout.HelpBox("提取完成！生成了" + extractedTexts.Count + "个本地化条目。", MessageType.Info);
            
            showExtractedTexts = EditorGUILayout.Foldout(showExtractedTexts, "显示提取的文本 (" + extractedTexts.Count + " 项)");
            
            if (showExtractedTexts)
            {
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                foreach (var kvp in extractedTexts)
                {
                    EditorGUILayout.LabelField(kvp.Key, EditorStyles.boldLabel);
                    EditorGUILayout.LabelField(kvp.Value, EditorStyles.wordWrappedLabel);
                    EditorGUILayout.Space();
                }
                EditorGUILayout.EndVertical();
            }
        }
    }
    
    public static Dictionary<string, string> ExtractTexts(string xmlPath, string outputJsonPath, string outputXmlPath = null)
    {
        if (string.IsNullOrEmpty(outputXmlPath))
        {
            outputXmlPath = xmlPath.Replace(".xml", "_localized.xml");
        }
        
        XmlDocument doc = new XmlDocument();
        doc.Load(xmlPath);
        
        Dictionary<string, string> texts = new Dictionary<string, string>();
        int counter = 0;
        
        // 提取所有summary节点
        XmlNodeList summaries = doc.GetElementsByTagName("summary");
        foreach (XmlNode node in summaries)
        {
            string key = GetParentMemberName(node) + "_Summary_" + (++counter);
            texts[key] = node.InnerText.Trim();
            
            // 替换为占位符
            node.InnerXml = "{{" + key + "}}";
        }
        
        // 同样处理其他标签类型
        counter = ExtractTagContent(doc, "para", texts, counter);
        counter = ExtractTagContent(doc, "remarks", texts, counter);
        counter = ExtractTagContent(doc, "example", texts, counter);
        counter = ExtractTagContent(doc, "code", texts, counter);
        counter = ExtractTagContent(doc, "param", texts, counter);
        counter = ExtractTagContent(doc, "returns", texts, counter);
        counter = ExtractTagContent(doc, "value", texts, counter);
        counter = ExtractTagContent(doc, "exception", texts, counter);
        
        // 保存修改后的XML
        doc.Save(outputXmlPath);
        
        // 保存提取的文本到JSON
        string json = JsonUtility.ToJson(new SerializableDictionary<string, string>(texts), true);
        File.WriteAllText(outputJsonPath, json);
        
        return texts;
    }
    
    private static string GetParentMemberName(XmlNode node)
    {
        // 尝试获取属性或方法的名称作为键的一部分
        if (node.ParentNode?.Attributes?["name"] != null)
        {
            string fullName = node.ParentNode.Attributes["name"].Value;
            string[] parts = fullName.Split('.');
            return parts[parts.Length - 1];
        }
        return "Unknown";
    }
    
    private static int ExtractTagContent(XmlDocument doc, string tagName, Dictionary<string, string> texts, int counter)
    {
        XmlNodeList nodes = doc.GetElementsByTagName(tagName);
        foreach (XmlNode node in nodes)
        {
            string key = GetParentMemberName(node) + "_" + tagName + "_" + (++counter);
            texts[key] = node.InnerText.Trim();
            node.InnerXml = "{{" + key + "}}";
        }
        return counter;
    }
    
    /// <summary>
    /// 从C#源代码中提取Odin特性中的文本
    /// </summary>
    public static Dictionary<string, string> ExtractAttributeTexts(string sourcePath, string outputJsonPath, bool includeSubfolders, string fileFilter, string[] attributeNames)
    {
        Dictionary<string, string> texts = new Dictionary<string, string>();
        
        // 获取所有符合条件的文件
        string[] files;
        if (includeSubfolders)
        {
            files = Directory.GetFiles(sourcePath, fileFilter, SearchOption.AllDirectories);
        }
        else
        {
            files = Directory.GetFiles(sourcePath, fileFilter, SearchOption.TopDirectoryOnly);
        }
        
        int counter = 0;
        
        // 为每个属性创建正则表达式
        List<Regex> attributePatterns = new List<Regex>();
        foreach (string attr in attributeNames)
        {
            // 匹配双引号字符串: [InfoBox("text")]
            attributePatterns.Add(new Regex(@"\[" + attr + @"\s*\(\s*""(.*?)""[\s,\)]", RegexOptions.Compiled | RegexOptions.Singleline));
            // 匹配verbatim双引号字符串: [InfoBox(@"text")]
            attributePatterns.Add(new Regex(@"\[" + attr + @"\s*\(\s*@""(.*?)""[\s,\)]", RegexOptions.Compiled | RegexOptions.Singleline));
            // 匹配单引号字符串: [InfoBox('text')]
            attributePatterns.Add(new Regex(@"\[" + attr + @"\s*\(\s*'(.*?)'[\s,\)]", RegexOptions.Compiled | RegexOptions.Singleline));
            // 匹配内插字符串: [InfoBox($"text")]
            attributePatterns.Add(new Regex(@"\[" + attr + @"\s*\(\s*\$""(.*?)""[\s,\)]", RegexOptions.Compiled | RegexOptions.Singleline));
        }
        
        foreach (string file in files)
        {
            try
            {
                string code = File.ReadAllText(file);
                string fileName = Path.GetFileNameWithoutExtension(file);
                
                foreach (Regex pattern in attributePatterns)
                {
                    MatchCollection matches = pattern.Matches(code);
                    foreach (Match match in matches)
                    {
                        if (match.Groups.Count > 1 && !string.IsNullOrEmpty(match.Groups[1].Value))
                        {
                            string text = match.Groups[1].Value.Trim();
                            
                            // 提取属性名
                            string patternStr = pattern.ToString();
                            int startIndex = patternStr.IndexOf("[") + 1;
                            int endIndex = patternStr.IndexOf("\\s*");
                            string attrName = patternStr.Substring(startIndex, endIndex - startIndex);
                            
                            // 生成键名：文件名_特性名_计数器
                            string key = $"{fileName}_{attrName}_{++counter}";
                            
                            // 如果文本已存在，使用不同的键名
                            while (texts.ContainsKey(key))
                            {
                                key = $"{fileName}_{attrName}_{++counter}";
                            }
                            
                            texts[key] = text;
                        }
                    }
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"处理文件 {file} 时出错: {e.Message}");
            }
        }
        
        // 保存提取的文本到JSON
        string json = JsonUtility.ToJson(new SerializableDictionary<string, string>(texts), true);
        File.WriteAllText(outputJsonPath, json);
        
        Debug.Log($"从源代码中提取了 {texts.Count} 个属性文本，已保存到 {outputJsonPath}");
        
        return texts;
    }
}

// 用于序列化Dictionary的辅助类
[System.Serializable]
public class SerializableDictionary<TKey, TValue>
{
    [SerializeField] private List<TKey> keys = new List<TKey>();
    [SerializeField] private List<TValue> values = new List<TValue>();
    
    public SerializableDictionary() { }
    
    public SerializableDictionary(Dictionary<TKey, TValue> dict)
    {
        foreach (var kvp in dict)
        {
            keys.Add(kvp.Key);
            values.Add(kvp.Value);
        }
    }
    
    public Dictionary<TKey, TValue> ToDictionary()
    {
        Dictionary<TKey, TValue> dict = new Dictionary<TKey, TValue>();
        for (int i = 0; i < Mathf.Min(keys.Count, values.Count); i++)
        {
            dict[keys[i]] = values[i];
        }
        return dict;
    }
}