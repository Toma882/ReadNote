# Odin Inspector 本地化工具

这是一个用于本地化Odin Inspector界面的工具，允许您将Odin Inspector的属性、说明和文档翻译成您需要的语言。

## 功能特性

- 从Odin Inspector的XML文档中提取文本，并用占位符替换
- 从C#源代码中提取Odin特性的文本内容（如InfoBox、Title等）
- 生成带有占位符的XML文档和包含原始文本的JSON文件
- 提供运行时加载本地化文件的功能
- 支持多语言切换
- 用户友好的编辑器界面

## 使用步骤

### 1. 选择需要本地化的内容类型

本工具提供两种提取方式：
- **XML文档提取**：提取Odin XML文档中的注释和说明
- **代码属性提取**：提取C#源代码中的Odin特性文本（InfoBox等）

### 2. XML文档提取流程

1. 在Unity菜单中选择 `Tools > Odin Inspector > 本地化提取工具`
2. 选择 `XML文档提取` 选项卡
3. 点击 `浏览` 按钮选择Odin Inspector的XML文档（通常位于 `Assets/Plugins/Sirenix/Assemblies` 下，例如 `Sirenix.OdinInspector.Attributes.xml`）
4. 设置输出XML路径（默认会在原文件路径下创建一个带有 `_localized` 后缀的文件）
5. 设置语言代码（默认为 `zh-CN`）
6. 设置输出JSON路径（默认会在原文件路径下创建一个带有语言代码后缀的文件）
7. 点击 `提取XML文档本地化文本` 按钮开始提取
8. 提取完成后，将生成两个文件：
   - 带有占位符的XML文件（例如 `Sirenix.OdinInspector.Attributes_localized.xml`）
   - 包含原始文本的JSON文件（例如 `Sirenix.OdinInspector.Attributes_zh-CN.json`）

### 3. 代码属性提取流程

1. 在Unity菜单中选择 `Tools > Odin Inspector > 本地化提取工具`
2. 选择 `代码属性提取` 选项卡
3. 点击 `浏览` 按钮选择包含Odin特性的C#源代码文件夹
4. 设置是否包括子文件夹以及文件过滤器（默认为 `*.cs`）
5. 设置输出JSON路径
6. 在特性列表中勾选需要提取的Odin特性（InfoBox、Title等）
7. 点击 `提取代码属性本地化文本` 按钮开始提取
8. 提取完成后，将生成一个包含所有提取文本的JSON文件

### 4. 翻译JSON文件

1. 打开生成的JSON文件，您将看到类似以下格式的内容：
   ```json
   {
     "AssetListAttribute_Summary_1": "AssetLists is used on lists and arrays and single elements of unity types...",
     "AssetListAttribute_Summary_2": "Use this to both filter and include or exclude assets...",
     "MyScript_InfoBox_1": "This is an info box message",
     ...
   }
   ```
2. 翻译JSON文件中的值（不要修改键名）
3. 保存翻译后的JSON文件

### 5. 设置本地化初始化器

1. 在您的场景中创建一个空的GameObject
2. 添加 `OdinLocalizationInitializer` 组件到GameObject上
3. 设置当前语言代码（例如 `zh-CN`）
4. 如果您的本地化文件不在默认位置，请设置自定义本地化路径
5. 确保 `启动时自动加载` 和 `在编辑器中加载` 选项已勾选
6. 点击 `立即加载本地化` 按钮立即应用本地化

### 6. 替换原始XML文件

对于XML文档本地化，您需要将带有占位符的XML文件（例如 `Sirenix.OdinInspector.Attributes_localized.xml`）重命名为原始文件名（例如 `Sirenix.OdinInspector.Attributes.xml`），或者在代码中修改Odin Inspector加载文档的路径。

对于代码属性本地化，您不需要修改源代码文件，因为本地化系统会在运行时自动应用翻译。

## 如何本地化代码中的特性文本

在您的代码中，当使用Odin特性如InfoBox时，其中的文本将被自动提取并可以被本地化：

```csharp
// 原始代码
[InfoBox("The AssetList attribute work on both lists of UnityEngine.Object types and UnityEngine.Object types, but have different behaviour.")]
public GameObject someField;

// 提取后，翻译系统会在运行时将其替换为本地化文本
// 无需修改源代码
```

支持的特性包括：
- InfoBox
- Title
- LabelText
- SuffixLabel
- GUIColor
- TabGroup
- BoxGroup
- FoldoutGroup
- ToggleGroup
- ButtonGroup
- HorizontalGroup
- VerticalGroup
- TitleGroup
- PropertyTooltip
- 等多种Odin特性

## 文件结构

- `OdinLocalizationExtractor.cs` - 提取文本和创建本地化文件的工具
- `OdinLocalizationLoader.cs` - 运行时加载和应用本地化文件的类
- `OdinLocalizationInitializer.cs` - 自动加载本地化文件的组件

## 建议的本地化文件存放位置

为了方便管理，建议将本地化文件存放在 `StreamingAssets/OdinLocalization` 文件夹下，例如：

```
StreamingAssets/
  OdinLocalization/
    Sirenix.OdinInspector.Attributes_zh-CN.json
    OdinAttributes_zh-CN.json  // 源代码特性本地化
    ...
```

如果您的项目不使用 `StreamingAssets` 文件夹，您也可以将文件存放在任何位置，并通过 `OdinLocalizationInitializer` 的 `自定义本地化路径` 选项指定。

## 注意事项

1. **备份原始文件** - 在替换Odin Inspector的XML文档之前，请务必备份原始文件。
2. **Unity升级** - 当升级Unity或Odin Inspector时，可能需要重新进行本地化过程，因为文档文件可能会被更新。
3. **文件权限** - 确保您有足够的权限访问和修改Odin Inspector的文件。
4. **简化占位符** - 占位符使用 `{{键名}}` 格式，请确保不要修改占位符的格式。
5. **XML解析限制** - 提取工具使用XML解析，可能对某些特殊格式的XML内容处理不完美，如遇问题请手动调整。
6. **动态文本** - 代码中使用的字符串插值或变量引用（如`$"Value: {value}"`）会被完整提取，但翻译时需注意保留原始变量引用。

## 高级用法

### 运行时切换语言

您可以通过 `OdinLocalizationInitializer` 组件的 `SwitchLanguage` 方法在运行时切换语言：

```csharp
OdinLocalizationInitializer.Instance.SwitchLanguage("en-US");
```

### 自定义本地化加载器

如果您需要更高级的本地化功能，您可以修改 `OdinLocalizationLoader` 类，例如添加对非JSON格式的支持，或者实现自动检测用户语言等功能。

### 合并多个JSON文件

当您有多个本地化JSON文件（例如XML文档和代码属性各自的文件）时，您可以手动将它们合并到一个文件中，或者使用`OdinLocalizationLoader`分别加载它们：

```csharp
// 先加载XML文档本地化
OdinLocalizationLoader.LoadLocalization("zh-CN", "path/to/xml_localization.json");
// 再加载代码属性本地化，它们会被合并到同一个字典中
OdinLocalizationLoader.LoadLocalization("zh-CN", "path/to/code_localization.json");
```

## 限制与未来改进

- 当前工具主要针对Odin Inspector的XML文档和代码特性，不处理其他类型的文件
- 目前不支持自动合并多个本地化文件
- 没有内置的翻译编辑器，需要手动编辑JSON文件
- 未来可能添加的功能：
  - 本地化编辑器界面
  - 自动化翻译API集成
  - 多文件批量处理
  - 版本控制支持
  - 对提取文本进行分类和组织 