/* =======================================================
 *  Unity版本：2021.3.0f1c1
 *  作 者：张寿昆
 *  邮 箱：136512892@qq.com
 *  创建时间：2025-05-11 21:27:06
 *  当前版本：1.0.0
 *  主要功能：
 *  详细描述：
 *  修改记录：
 * =======================================================*/

using System.IO;
using System.Collections.Generic;
using UnityEngine;
using System.Text.RegularExpressions;

/// <summary>
/// Odin本地化加载器，用于在运行时加载和应用Odin Inspector的本地化文件
/// </summary>
public class OdinLocalizationLoader
{
    private static Dictionary<string, string> localizedTexts;
    private static bool isInitialized = false;
    
    /// <summary>
    /// 加载指定语言的本地化文件
    /// </summary>
    /// <param name="language">语言代码，例如"zh-CN"</param>
    /// <param name="customPath">自定义路径，如果为null则使用默认路径</param>
    /// <returns>是否成功加载</returns>
    public static bool LoadLocalization(string language, string customPath = null)
    {
        string path;
        
        if (customPath != null)
        {
            path = customPath;
        }
        else
        {
            // 默认路径：StreamingAssets/OdinLocalization/
            path = Path.Combine(Application.streamingAssetsPath, "OdinLocalization", $"Sirenix.OdinInspector.Attributes_{language}.json");
        }
        
        if (File.Exists(path))
        {
            try
            {
                string json = File.ReadAllText(path);
                SerializableDictionary<string, string> serDict = JsonUtility.FromJson<SerializableDictionary<string, string>>(json);
                localizedTexts = serDict.ToDictionary();
                isInitialized = true;
                Debug.Log($"已加载Odin本地化文件: {path}, 共{localizedTexts.Count}个条目");
                return true;
            }
            catch (System.Exception e)
            {
                Debug.LogError($"加载Odin本地化文件失败: {e.Message}");
                return false;
            }
        }
        else
        {
            Debug.LogWarning($"未找到Odin本地化文件: {path}");
            return false;
        }
    }
    
    /// <summary>
    /// 应用本地化到XML内容
    /// </summary>
    /// <param name="xmlContent">含有占位符的XML内容</param>
    /// <returns>替换占位符后的XML内容</returns>
    public static string ApplyLocalization(string xmlContent)
    {
        if (!isInitialized || localizedTexts == null || localizedTexts.Count == 0)
            return xmlContent;
        
        return Regex.Replace(xmlContent, @"\{\{(\w+)\}\}", match =>
        {
            string key = match.Groups[1].Value;
            return localizedTexts.ContainsKey(key) ? localizedTexts[key] : match.Value;
        });
    }
    
    /// <summary>
    /// 获取本地化文本
    /// </summary>
    /// <param name="key">本地化键</param>
    /// <returns>本地化文本，如果未找到则返回键名</returns>
    public static string GetLocalizedText(string key)
    {
        if (!isInitialized || localizedTexts == null || !localizedTexts.ContainsKey(key))
            return key;
            
        return localizedTexts[key];
    }
    
    /// <summary>
    /// 重置本地化加载器
    /// </summary>
    public static void Reset()
    {
        localizedTexts = null;
        isInitialized = false;
    }
    
    /// <summary>
    /// 判断本地化加载器是否已初始化
    /// </summary>
    public static bool IsInitialized => isInitialized;
    
    /// <summary>
    /// 获取已加载的本地化条目数量
    /// </summary>
    public static int EntryCount => localizedTexts?.Count ?? 0;
}