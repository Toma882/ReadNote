/* =======================================================
 *  Unity版本：2020.3.16f1c1
 *  作 者：张寿昆
 *  邮 箱：136512892@qq.com
 *  创建时间：2023-12-28 14:47:41
 *  当前版本：1.0.0
 *  主要功能：
 *  详细描述：
 *  修改记录：
 * =======================================================*/

using UnityEngine;

[AddComponentMenu("Event Graph")]
public class EventGraphComponent : MonoBehaviour
{
    [SerializeField] private EventGraph graph;
}