/* =======================================================
 *  Unity版本：2021.3.0f1c1
 *  作 者：张寿昆
 *  邮 箱：136512892@qq.com
 *  创建时间：2025-05-11 21:27:06
 *  当前版本：1.0.0
 *  主要功能：
 *  详细描述：
 *  修改记录：
 * =======================================================*/

using UnityEngine;
using System.IO;
#if UNITY_EDITOR
using UnityEditor;
#endif

/// <summary>
/// Odin本地化初始化器，在Unity启动时自动加载Odin本地化文件
/// </summary>
[ExecuteInEditMode]
public class OdinLocalizationInitializer : MonoBehaviour
{
    [Tooltip("当前语言，例如zh-CN、en-US等")]
    public string currentLanguage = "zh-CN";
    
    [Tooltip("自定义本地化文件路径，如果为空则使用默认路径")]
    public string customLocalizationPath = "";
    
    [Tooltip("是否在启动时自动加载")]
    public bool loadOnStart = true;
    
    [Tooltip("是否在编辑器中加载")]
    public bool loadInEditor = true;
    
    private static OdinLocalizationInitializer _instance;
    
    public static OdinLocalizationInitializer Instance 
    {
        get 
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<OdinLocalizationInitializer>();
                
                if (_instance == null && Application.isPlaying)
                {
                    GameObject go = new GameObject("OdinLocalizationInitializer");
                    _instance = go.AddComponent<OdinLocalizationInitializer>();
                    DontDestroyOnLoad(go);
                }
            }
            return _instance;
        }
    }
    
    private void Awake()
    {
        if (_instance != null && _instance != this)
        {
            DestroyImmediate(gameObject);
            return;
        }
        
        _instance = this;
        
        if (Application.isPlaying)
        {
            DontDestroyOnLoad(gameObject);
        }
        
        if (loadOnStart)
        {
            LoadLocalization();
        }
    }
    
    private void OnEnable()
    {
        if (loadInEditor && !Application.isPlaying)
        {
            LoadLocalization();
        }
    }
    
    /// <summary>
    /// 加载当前语言的本地化文件
    /// </summary>
    /// <returns>是否成功加载</returns>
    public bool LoadLocalization()
    {
        string path = !string.IsNullOrEmpty(customLocalizationPath) ? customLocalizationPath : null;
        return OdinLocalizationLoader.LoadLocalization(currentLanguage, path);
    }
    
    /// <summary>
    /// 切换语言
    /// </summary>
    /// <param name="language">新的语言代码</param>
    /// <returns>是否成功切换</returns>
    public bool SwitchLanguage(string language)
    {
        if (currentLanguage == language)
            return true;
            
        currentLanguage = language;
        return LoadLocalization();
    }
}

#if UNITY_EDITOR
[CustomEditor(typeof(OdinLocalizationInitializer))]
public class OdinLocalizationInitializerEditor : Editor
{
    private string[] availableLanguages = new string[] { "zh-CN", "en-US" };
    private int languageIndex = 0;
    private bool showDebugInfo = false;
    
    public override void OnInspectorGUI()
    {
        OdinLocalizationInitializer initializer = (OdinLocalizationInitializer)target;
        
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("Odin本地化初始化器", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox("此组件用于自动加载Odin Inspector的本地化文件。\n请确保您已经使用Odin本地化提取工具生成了本地化文件。", MessageType.Info);
        
        EditorGUILayout.Space(5);
        
        // 语言选择
        for (int i = 0; i < availableLanguages.Length; i++)
        {
            if (availableLanguages[i] == initializer.currentLanguage)
            {
                languageIndex = i;
                break;
            }
        }
        
        EditorGUI.BeginChangeCheck();
        languageIndex = EditorGUILayout.Popup("当前语言:", languageIndex, availableLanguages);
        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(initializer, "Change Language");
            initializer.currentLanguage = availableLanguages[languageIndex];
            EditorUtility.SetDirty(initializer);
        }
        
        EditorGUILayout.Space(5);
        
        // 自定义路径
        EditorGUILayout.BeginHorizontal();
        initializer.customLocalizationPath = EditorGUILayout.TextField("自定义本地化路径:", initializer.customLocalizationPath);
        if (GUILayout.Button("浏览", GUILayout.Width(60)))
        {
            string path = EditorUtility.OpenFilePanel("选择本地化JSON文件", Application.dataPath, "json");
            if (!string.IsNullOrEmpty(path))
            {
                initializer.customLocalizationPath = path;
            }
        }
        EditorGUILayout.EndHorizontal();
        
        EditorGUILayout.Space(2);
        
        // 其他选项
        initializer.loadOnStart = EditorGUILayout.Toggle("启动时自动加载", initializer.loadOnStart);
        initializer.loadInEditor = EditorGUILayout.Toggle("在编辑器中加载", initializer.loadInEditor);
        
        EditorGUILayout.Space(10);
        
        // 手动加载按钮
        if (GUILayout.Button("立即加载本地化", GUILayout.Height(30)))
        {
            bool success = initializer.LoadLocalization();
            if (success)
            {
                EditorUtility.DisplayDialog("加载成功", $"已成功加载{initializer.currentLanguage}语言的本地化文件。\n共加载了{OdinLocalizationLoader.EntryCount}个本地化条目。", "确定");
            }
            else
            {
                EditorUtility.DisplayDialog("加载失败", "加载本地化文件失败，请检查文件路径和格式是否正确。", "确定");
            }
        }
        
        EditorGUILayout.Space(5);
        
        // 调试信息
        showDebugInfo = EditorGUILayout.Foldout(showDebugInfo, "调试信息");
        if (showDebugInfo)
        {
            EditorGUI.indentLevel++;
            EditorGUILayout.LabelField("本地化状态:", OdinLocalizationLoader.IsInitialized ? "已初始化" : "未初始化");
            EditorGUILayout.LabelField("本地化条目数:", OdinLocalizationLoader.EntryCount.ToString());
            EditorGUILayout.LabelField("推荐存放位置:", Path.Combine(Application.streamingAssetsPath, "OdinLocalization"));
            EditorGUI.indentLevel--;
        }
    }
}
#endif